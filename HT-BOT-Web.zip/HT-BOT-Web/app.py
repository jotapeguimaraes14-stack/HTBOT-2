import os
import requests
import gradio as gr

API_URL = "https://openrouter.ai/api/v1/chat/completions"
MODEL = os.getenv("OPENROUTER_MODEL", "openrouter/free")


def responder(mensagem, historico):
    chave = os.getenv("OPENROUTER_API_KEY", "").strip()
    if not chave:
        return "O HT-BOT ainda não foi configurado. O administrador precisa adicionar a variável secreta OPENROUTER_API_KEY na hospedagem."

    mensagens = [{
        "role": "system",
        "content": (
            "Você é o HT-BOT, assistente da HIPER TECH. "
            "Responda em português brasileiro, com clareza, educação e criatividade."
        )
    }]

    for item in (historico or []):
        if not isinstance(item, dict):
            continue
        role, content = item.get("role"), item.get("content")
        if role in ("user", "assistant") and isinstance(content, str) and content.strip():
            mensagens.append({"role": role, "content": content})

    if not isinstance(mensagem, str) or not mensagem.strip():
        return "Digite uma mensagem para conversar com o HT-BOT."
    mensagens.append({"role": "user", "content": mensagem.strip()})

    try:
        resposta = requests.post(
            API_URL,
            headers={
                "Authorization": f"Bearer {chave}",
                "Content-Type": "application/json",
                "X-Title": "HIPER TECH HT-BOT"
            },
            json={
                "model": MODEL,
                "messages": mensagens,
                "temperature": 0.7,
                "max_tokens": 700
            },
            timeout=(15, 90)
        )

        if not resposta.ok:
            try:
                detalhe = resposta.json().get("error", {}).get("message", "")
            except (ValueError, AttributeError):
                detalhe = ""
            if resposta.status_code == 401:
                return "A OpenRouter recusou a chave. Confira OPENROUTER_API_KEY na hospedagem."
            if resposta.status_code == 402:
                return "A OpenRouter informou que não há créditos disponíveis para essa solicitação."
            if resposta.status_code == 429:
                return "A OpenRouter está limitando as solicitações. Espere um pouco e tente novamente."
            if detalhe:
                return f"A OpenRouter retornou o erro {resposta.status_code}: {detalhe[:350]}"
            return f"A OpenRouter retornou o erro HTTP {resposta.status_code}."

        dados = resposta.json()
        conteudo = dados["choices"][0]["message"]["content"]
        if isinstance(conteudo, str) and conteudo.strip():
            return conteudo
        return "A IA retornou uma resposta vazia. Tente novamente."

    except requests.Timeout:
        return "A resposta demorou demais. Tente novamente."
    except requests.RequestException:
        return "Não consegui conectar à OpenRouter. Tente novamente."
    except (KeyError, IndexError, ValueError, TypeError):
        return "A API retornou uma resposta inesperada. Tente novamente."


app = gr.ChatInterface(
    fn=responder,
    type="messages",
    title="HIPER TECH | HT-BOT",
    description="Seu assistente inteligente da HIPER TECH.",
    textbox=gr.Textbox(
        placeholder="Digite sua mensagem...",
        lines=2,
        max_lines=6
    ),
    submit_btn="Enviar",
    clear_btn="Nova conversa"
)

if __name__ == "__main__":
    app.launch(
        server_name="0.0.0.0",
        server_port=int(os.getenv("PORT", "7860"))
    )
