# HIPER TECH | HT-BOT (versão web)

Esta é uma versão web do HT-BOT. Diferente do arquivo original `HTBOT.py`,
que usa Tkinter e abre uma janela do Windows, esta versão usa Gradio e funciona no navegador.

## Arquivos
- `app.py`: aplicativo web.
- `requirements.txt`: dependências Python.

## Configuração obrigatória
Configure a variável de ambiente secreta:
- Nome: `OPENROUTER_API_KEY`
- Valor: sua chave secreta da OpenRouter

Opcional:
- `OPENROUTER_MODEL`: modelo a usar. O padrão é `openrouter/free`.
- `PORT`: normalmente definido automaticamente pela hospedagem.

**Nunca coloque a chave da OpenRouter dentro do código nem a envie para um repositório público.**

## Executar no computador
1. Instale Python 3.10 ou mais recente.
2. Abra o terminal nesta pasta.
3. Execute `pip install -r requirements.txt`.
4. Configure `OPENROUTER_API_KEY` como variável de ambiente.
5. Execute `python app.py`.

No Windows PowerShell, para configurar a chave apenas na janela atual:
`$env:OPENROUTER_API_KEY="SUA_CHAVE_AQUI"`

Depois abra o endereço local indicado no terminal.

## Publicar
Use uma hospedagem que aceite aplicações Python/Gradio. Configure:
- Build command: `pip install -r requirements.txt`
- Start command: `python app.py`
- Secret/environment variable: `OPENROUTER_API_KEY`

Planos gratuitos podem ter limites, e a disponibilidade do modelo gratuito da OpenRouter não é garantida.
